<!DOCTYPE html>
<html lang="es">
    <head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <meta charset="utf-8" />
        <title>Hola Mundo!</title>
        <style>
                table {
                border-collapse: collapse;
                }

                table, th, td {
                border: 1px solid black;
                }
                
        
</style>
<script>
$( document ).ready(function() {
});


</script>
    </head>
    <body>
<table>
<tr>
    <td>1. Datos Generales del Contrato 			</td>
</tr>
<tr>
    <td>  Nombre Empresa Cliente 			</td>
    <td></td>
    <td>  Nombre  Empresa  Temporal  - EST  </td>
    <td></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
    <td>  Nombre Empresa Cliente 			</td>
    <td></td>
    <td>  Nombre  Empresa  Temporal  - EST  </td>
    <td></td>
</tr>
</table>
</body>
</html>